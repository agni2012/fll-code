def run5():
    # PortA is right arm motor
    # PortB is left arm motor
    # PortD is left drive motor
    # PortF is right drive motor
    from pybricks.hubs import PrimeHub
    from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
    from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
    from pybricks.robotics import DriveBase
    from pybricks.tools import wait, StopWatch

    hub = PrimeHub()
    total = 0
    for i in range(100):
        total += hub.battery.voltage()
    battery = total / 100
    print("\x1b[H\x1b[2J", end="")
    print('Battery: ' + str(round((battery-6000)/23)) + '%')
    l_motor = Motor(Port.D, Direction.COUNTERCLOCKWISE)
    r_motor = Motor(Port.F)
    l_arm_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
    r_arm_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    robot = DriveBase(l_motor, r_motor, 56, 159)

    robot.settings(
        straight_speed = 800,
        straight_acceleration = 800,
        turn_rate = 150
    )

    l_arm_motor.run_angle(100, 120)
        

    robot.use_gyro(True)

    robot.arc(4700, distance = 650)
    robot.turn(-53);
    robot.straight(190)

    r_arm_motor.run_angle(100, -160)
    robot.straight(-100)
    """
    robot.turn(127)
    l_arm_motor.run_angle(100, -147)
    robot.straight(220)

    l_arm_motor.run_angle(100, 37, wait = False)
    wait(700);
    robot.settings(straight_acceleration=100)
    robot.settings(straight_speed=100)
    robot.straight(-257)
    l_arm_motor.stop();
    robot.settings(turn_acceleration=100)
    robot.settings(turn_rate=100)
    robot.turn(90);
    robot.straight(300)
    robot.turn(30)
    robot.straight(300)
    """

    robot.turn(50)
    robot.straight(-700)
