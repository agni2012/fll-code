print("-- started --")

from pybricks.hubs import PrimeHub
from pybricks.tools import hub_menu
from run1 import run1
from run2 import run2
from run3 import run3
from run4 import run4
from run5 import run5
from run6 import run6

hub = PrimeHub()

programs = [
	run1, run2, run3, run4, run5, run6
]

# Get last run from memory
last = [v for v in hub.system.storage(0, read=1)]
start = (last[0] + 1) % len(programs) if last else 0

# Rotate menu
menu = [(((start + i) % len(programs))) for i in range(len(programs))]
def add1str(x):
	l = [];
	for i in x:
		l.append(str(i + 1));
	return l;
selected = int(hub_menu(*add1str(menu)))
# Run selected program
try: programs[selected]()
except: print("Run error:", selected)

# Save selected
hub.system.storage(0, write=bytes([selected]))
