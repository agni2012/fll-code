def run1():
    from pybricks.hubs import PrimeHub
    from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
    from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
    from pybricks.robotics import DriveBase
    from pybricks.tools import wait, StopWatch

    hub = PrimeHub()
    total = 0
    for i in range(100):
        total += hub.battery.voltage()
    battery = total / 100
    print("\x1b[H\x1b[2J", end="")
    print('Battery: ' + str(round((battery-6000)/23)) + '%')
    l_motor = Motor(Port.D, Direction.COUNTERCLOCKWISE)
    r_motor = Motor(Port.F)
    arm_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
    robot = DriveBase(l_motor, r_motor, 56, 159)
    robot.settings(
        straight_speed = 900,
        straight_acceleration = 900,
        turn_rate = 200
    )
    """
    arm_motor.run_angle(200, 30)

    arm_motor.run_angle(200, -15)

    while True:
        arm_motor.run(-100)
        if(arm_motor.load() > 50):
            break;

    arm_motor.run_angle(40, 28)
    """
    robot.use_gyro(True)
    #arm_motor.run_angle(70,108.14159265358979323846264338327950288)
    
    arm_motor.hold();
    #brush mission
    robot.straight(530)
    robot.straight(-55, then = Stop.NONE)

    arm_motor.run_angle(570,-25, wait = False)
    robot.straight(-40, wait = False)
    # arm_motor.run_angle(570,-25, wait = False)
    robot.straight(-255)
    robot.settings(
        straight_speed = 500,
        straight_acceleration = 700,
        turn_rate = 200
    )
    robot.straight(300, then =  Stop.NONE)
    robot.settings(
        straight_speed = 200
    )
    robot.arc(144, angle = 90, then = Stop.NONE)
    robot.settings(
        straight_speed = 500
    )

    #arm_motor.run_angle(170,-105, wait = False)
    #whats on the scale
    
    robot.straight(400)
    
    robot.turn(-40)
    robot.straight(250, then = Stop.NONE)
    robot.arc(105, angle = 82, then = Stop.NONE);
    robot.straight(230)
    robot.settings( straight_speed = 200, straight_acceleration=100)
    robot.straight(120)
    robot.settings( straight_speed = 500, straight_acceleration=500)


    robot.straight(-200)


    robot.turn(60)
    robot.straight(-70)
    arm_motor.run_angle(100, -24,wait=False)
    robot.straight(190)
    arm_motor.run_angle(100, -50)
    arm_motor.run_angle(300, 50,wait=False)

    robot.arc(650, angle = 70, then = Stop.NONE);
    robot.straight(700)