# print("-- started --")

# from pybricks.hubs import PrimeHub
# from pybricks.tools import hub_menu
# from run1 import run1
# from run2 import run2
# from run3 import run3
# from run4 import run4
# from run5 import run5
# from run6 import run6
# from run7 import run7
# from run7full import run7full
# from CWC import cwc
# from reset_r_1 import rr1

# hub = PrimeHub()

# programs = [
# 	run1, run2, run3, run4, run5, run6, run7, run7full, cwc, rr1
# ]

# # Get last run from memory
# last = [v for v in hub.system.storage(0, read=1)]
# start = (last[0] + 1) % len(programs) if last else 0

# # Rotate menu
# menu = [(((start + i) % len(programs))) for i in range(len(programs))]
# strConv = {
# 	"1":"1",
# 	"2":"2",
# 	"3":"3",
# 	"4":"4",
# 	"5":"5",
# 	"6":"6",
# 	"7":"7",
# 	"8":"f",
# 	"9":"c",
# 	"10":"r",
# }
# def add1str(x):
# 	l = [];
# 	for i in x:
# 		l.append(strConv[str(i + 1)]);
# 	return l;

# selected = int(hub_menu(*add1str(menu)))-1
# # Run selected program

# # Save selected
# hub.system.storage(0, write=bytes([selected]))
# programs[selected]()


print("-- started --")

from pybricks.hubs import PrimeHub
from pybricks.tools import hub_menu
from run1 import run1
from run2 import run2
from run3 import run3
from run4 import run4
from run5 import run5
from run6 import run6
from run7 import run7
from run7full import run7full
from CWC import cwc
from reset_r_1 import rr1

hub = PrimeHub()

programs = [
	run1, run2, run3, run4, run5, run6, run7, run7full, cwc, rr1
]

# Get last run from memory
last = [v for v in hub.system.storage(0, read=1)]
start = (last[0] + 1) % len(programs) if last else 0

# Rotate menu
menu = [(start + i) % len(programs) for i in range(len(programs))]

# Menu display mapping (numbers or letters)
strConv = {
	0: "1", 1: "2", 2: "3", 3: "4", 4: "5",
	5: "6", 6: "7", 7: "F", 8: "C", 9: "R"
}

# Inverse mapping to get program index from menu selection
invStrConv = {v: k for k, v in strConv.items()}

# Convert menu indices to display strings
menu_display = [strConv[i] for i in menu]

# Show menu and get selection
selected_str = hub_menu(*menu_display)
selected = invStrConv[selected_str]

# Save selected
hub.system.storage(0, write=bytes([selected]))

# Run the selected program
programs[selected]()
