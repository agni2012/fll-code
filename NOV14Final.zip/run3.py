def run3():
    # PortA is right arm motor
    # PortB is left arm motor
    # PortD is left drive motor
    # PortF is right drive motor
    from pybricks.hubs import PrimeHub
    from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
    from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
    from pybricks.robotics import DriveBase
    from pybricks.tools import wait, StopWatch

    hub = PrimeHub()
    total = 0
    for i in range(100):
        total += hub.battery.voltage()
    battery = total / 100
    print("\x1b[H\x1b[2J", end="")
    print('Battery: ' + str(round((battery-6000)/23)) + '%')
    l_motor = Motor(Port.D, Direction.COUNTERCLOCKWISE)
    r_motor = Motor(Port.F)
    l_arm_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
    r_arm_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    robot = DriveBase(l_motor, r_motor, 56, 159)

    robot.settings(
        straight_speed = 700,
        straight_acceleration = 700,
        turn_rate = 150
    )

    robot.use_gyro(True)
    time = StopWatch()
    while True:
        r_arm_motor.run(-100)
        if(r_arm_motor.load() > 67 or time.time()>2001):
            break;
    r_arm_motor.run_angle(100, 5, wait= False);
    wait(250)
    r_arm_motor.stop();

    robot.straight(355)
    #taking the preserved things out

    for i in range(4):
        r_arm_motor.run_angle(1000,50)
        r_arm_motor.run_angle(1000,-50, wait = False)
        wait(1000);

    # turn left to go around silo
    robot.turn(-26.7)
    robot.straight(270)

    #aim to heavy lifting
    robot.turn(57)
    r_arm_motor.run_angle(100,70);
    robot.straight(63);
    #get current arm angle
    p_a = r_arm_motor.angle();
    #lift with max force
    r_arm_motor.run_time(-70000, 1000);
    #fling the weight
    robot.turn(60);
    robot.straight(10);
    #if the arm actually moved, it must have missed the weight, so compensate
    if(r_arm_motor.angle()-p_a>60):
        r_arm_motor.run_target(100, p_a);

    r_arm_motor.run_angle(100, -12); # neg 5 important

    # robot.turn(-50);
    robot.arc(10, -50)
    robot.straight(30)
    
    robot.turn(-20);
    r_arm_motor.run_angle(100, 9 , wait = True);
    
    robot.turn(-30);
    r_arm_motor.hold(); 
    
    robot.turn(-35)

    r_arm_motor.run(-100)
    #done

    robot.turn(40)
    robot.arc(3000, distance= -655)
